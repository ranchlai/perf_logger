Performance logging services for training deep neural networks. 


